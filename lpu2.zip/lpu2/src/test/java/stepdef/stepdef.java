package stepdef;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;
import junit.framework.Assert;		
public class stepdef
{				
 	WebDriver d ;
 	@Before
 	  public void opened()
 	  {
 		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
 		  d=new ChromeDriver();
 	  }
 	
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	//  d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
        
        //throw new PendingException();
     }		
 @Then("^verify title$")					
    public void verifytitle() throws Throwable 							
    {    		
    	 String a=d.getTitle();
	        System.out.println("title="+a);
Assert.assertEquals("KSRTC Official Website for Online Bus Ticket Booking - KSRTC.in", a);
		    if(a.matches("KSRTC Official Website for Online Bus Ticket Booking - KSRTC.in")) 
		    {
		        System.out.println("titile is correct-No defect");

		    }
		    else
		    {
		        System.out.println("titile is not correct-A defect");
		    }
	      //throw new PendingException();

	 }		
 
 @Then("^verify text$")
 public void verify_text() throws Throwable
 {
   boolean text=d.getPageSource().contains("Welcome to KSRTC");
   if(text) 
   {
       System.out.println("text is present on home page-No defect");

   }
   else
   {
       System.out.println("text is not present on home page-A defect");
   }
//throw new PendingException();
 }
@After
  public void closed()
  {
	d.close();
  }

}